var Employee = (function () {
    function Employee(empId, empName, empSalary, empDesig) {
        var _this = this;
        this.display = function () {
            console.log(JSON.stringify(_this));
        };
        this.employeeId = empId;
        this.empName = empName;
        this.empSalary = empSalary;
        this.empDesignation = empDesig;
    }
    return Employee;
})();
exports.Employee = Employee;

var Employee_1 = require("../Employee");
var employee = new Employee_1.Employee(1, "abhi", 100, "trainer");
employee.display();

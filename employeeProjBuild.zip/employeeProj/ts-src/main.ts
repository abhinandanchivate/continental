import { Employee } from "./Employee";
let employee: Employee = new Employee(1, "abhi", 100, "trainer");
employee.display();
console.log("hello");
console.log("hello from continental");

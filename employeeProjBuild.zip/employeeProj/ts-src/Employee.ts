export class Employee {
  employeeId: number;
  empName: string;
  empSalary: number;
  empDesignation: string;

  constructor(
    empId: number,
    empName: string,
    empSalary: number,
    empDesig: string
  ) {
    this.employeeId = empId;
    this.empName = empName;
    this.empSalary = empSalary;
    this.empDesignation = empDesig;
  }

  display = () => {
    console.log(JSON.stringify(this));
  };
}

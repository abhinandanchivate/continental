export class Employee {
    constructor(empId, empName, empSalary, empDesig) {
        this.display = () => {
            console.log(JSON.stringify(this));
        };
        this.employeeId = empId;
        this.empName = empName;
        this.empSalary = empSalary;
        this.empDesignation = empDesig;
    }
}
